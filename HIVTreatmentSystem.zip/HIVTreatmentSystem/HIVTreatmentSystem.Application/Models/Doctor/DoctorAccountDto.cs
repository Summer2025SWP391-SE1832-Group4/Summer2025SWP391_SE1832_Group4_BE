namespace HIVTreatmentSystem.Application.Models.Doctor
{
    public class DoctorAccountDto
    {
        public int AccountId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Status { get; set; } = string.Empty;
    }
} 