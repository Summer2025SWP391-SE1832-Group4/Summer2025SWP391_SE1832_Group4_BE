﻿

namespace HIVTreatmentSystem.Application.Models.Requests
{
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }
}
