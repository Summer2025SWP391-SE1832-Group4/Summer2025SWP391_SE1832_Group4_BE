﻿

namespace HIVTreatmentSystem.Application.Models.Responses
{
    public class ChangePasswordResponse
    {
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
