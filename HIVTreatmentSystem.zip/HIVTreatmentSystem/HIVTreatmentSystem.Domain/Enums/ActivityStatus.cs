﻿namespace HIVTreatmentSystem.Domain.Enums
{
    public enum ActivityStatus
    {
        Scheduled,
        Completed,
        Canceled,
    }
}
