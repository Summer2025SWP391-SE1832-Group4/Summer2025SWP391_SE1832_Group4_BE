﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum ScheduleAvailability
    {
        Available,
        OnLeave,
        Booked,
    }
}
