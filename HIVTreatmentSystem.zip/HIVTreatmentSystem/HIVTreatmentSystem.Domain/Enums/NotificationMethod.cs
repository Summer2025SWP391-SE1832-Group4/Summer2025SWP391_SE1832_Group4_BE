﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum NotificationMethod
    {
        SMS,
        Email,
        InApp,
    }
}
