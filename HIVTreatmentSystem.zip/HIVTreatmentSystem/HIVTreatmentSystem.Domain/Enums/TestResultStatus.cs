namespace HIVTreatmentSystem.Domain.Enums;

public class TestResultStatus
{
    // public Enum TestResultServiceStatus
    // {
    //   
    // }
    
}