﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum ReminderType
    {
        TakeMedication,
        FollowUpAppointment,
    }
}
