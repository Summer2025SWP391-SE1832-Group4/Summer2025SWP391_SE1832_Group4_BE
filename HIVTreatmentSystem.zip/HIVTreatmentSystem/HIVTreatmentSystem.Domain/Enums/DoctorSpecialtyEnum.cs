﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum DoctorSpecialtyEnum
    {
        Consultant,
        Testing,
        Therapy
    }

}
