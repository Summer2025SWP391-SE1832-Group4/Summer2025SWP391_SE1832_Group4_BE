﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum AdverseEffectReportStatusEnum
    {
        Pending,
        Reviewed,
        Ignored,
        Resolved
    }
}
