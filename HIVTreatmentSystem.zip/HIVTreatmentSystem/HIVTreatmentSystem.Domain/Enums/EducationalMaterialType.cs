﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum EducationalMaterialType
    {
        Article,
        Video,
        BlogPost,
        StigmaReductionMaterial,
        FAQ,
    }
}
