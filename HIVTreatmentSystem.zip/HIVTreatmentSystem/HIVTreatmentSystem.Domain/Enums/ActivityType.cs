﻿namespace HIVTreatmentSystem.Domain.Enums
{
    public enum ActivityType
    {
        ReExamination,
        LabTest,
        MedicationPickup,
    }
}
