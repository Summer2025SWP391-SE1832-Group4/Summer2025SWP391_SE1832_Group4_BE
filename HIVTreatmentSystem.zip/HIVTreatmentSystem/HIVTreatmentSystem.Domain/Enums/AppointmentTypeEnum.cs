﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum AppointmentTypeEnum
    {
        Consultation,
        Testing,
        Therapy
    }
}
