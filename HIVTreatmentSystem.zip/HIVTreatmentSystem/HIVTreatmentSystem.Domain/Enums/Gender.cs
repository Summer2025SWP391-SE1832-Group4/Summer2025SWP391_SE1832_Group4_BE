﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum Gender
    {
        Male,
        Female,
        Other,
    }
}
