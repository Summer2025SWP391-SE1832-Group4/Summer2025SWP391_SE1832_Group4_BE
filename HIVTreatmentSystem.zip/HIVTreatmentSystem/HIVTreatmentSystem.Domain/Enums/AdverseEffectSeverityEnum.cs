﻿

namespace HIVTreatmentSystem.Domain.Enums
{
    public enum AdverseEffectSeverityEnum
    {
    Mild,       
    Moderate,    
    Severe,      
    LifeThreatening 
    }
}
